API数据源功能部署包
==================

部署步骤：
---------

1. 上传此压缩包到服务器
   scp api-source-deploy-*.tar.gz user@server:/path/to/

2. SSH登录服务器
   ssh user@server

3. 解压到项目目录
   cd /path/to/rag-website
   tar -xzf /path/to/api-source-deploy-*.tar.gz --strip-components=1

4. 备份现有文件（可选但推荐）
   cp main.py main.py.backup
   cp static/index.html static/index.html.backup

5. 设置执行权限
   chmod +x test_*.sh deploy_with_retry.sh

6. 安装依赖
   .venv/bin/pip install -q --upgrade pip
   .venv/bin/pip install -q -r requirements.txt

7. 测试功能（可选）
   .venv/bin/python test_api_source.py
   .venv/bin/python test_transform.py

8. 重启服务
   sudo systemctl restart qa-chat

9. 验证服务
   sudo systemctl status qa-chat
   journalctl -u qa-chat -n 20

10. 访问界面
    http://your-server:8000

新增功能：
---------
✓ API数据源管理
✓ 单接口模式
✓ 列表+详情模式
✓ 树形结构扁平化
✓ 数据转换脚本

文档：
-----
- QUICKSTART.md - 快速上手
- API_SOURCE_GUIDE.md - 详细指南
- TRANSFORM_GUIDE.md - 转换功能
- MANUAL_DEPLOY.md - 手动部署指南

问题排查：
---------
如遇问题，查看：
- journalctl -u qa-chat -n 50
- MANUAL_DEPLOY.md

